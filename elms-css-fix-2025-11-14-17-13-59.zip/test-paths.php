<?php
// Path debugging for InfinityFree
echo "<h3>Path Debug Information</h3>";
echo "<p><strong>SCRIPT_NAME:</strong> " . $_SERVER["SCRIPT_NAME"] . "</p>";
echo "<p><strong>Current Directory:</strong> " . dirname($_SERVER["SCRIPT_NAME"]) . "</p>";

$currentScript = $_SERVER["SCRIPT_NAME"];
$currentDir = dirname($currentScript);
$currentDir = ltrim($currentDir, "/");
$levels = empty($currentDir) ? 0 : substr_count($currentDir, "/");

if ($levels == 0) {
    $basePath = "./";
} else {
    $basePath = str_repeat("../", $levels);
}

echo "<p><strong>Calculated Base Path:</strong> " . htmlspecialchars($basePath) . "</p>";
echo "<p><strong>CSS Path:</strong> " . htmlspecialchars($basePath . "css/style.css") . "</p>";

// Test if CSS file exists
$cssPath = $basePath . "css/style.css";
if (file_exists($cssPath)) {
    echo "<p style=\"color: green;\">✅ CSS file found at: " . htmlspecialchars($cssPath) . "</p>";
} else {
    echo "<p style=\"color: red;\">❌ CSS file NOT found at: " . htmlspecialchars($cssPath) . "</p>";
}
?>